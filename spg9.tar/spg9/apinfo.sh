#!/bin/bash

dmesg -c| grep clearflg123

iwpriv ra0 show stacountinfo

check_results=`dmesg | grep -c  ..:..:..:..:..:..`

echo "clientnum=$check_results"